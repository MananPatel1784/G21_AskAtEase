const loginBtn = document.getElementById('login-button');
const signupLink = document.getElementById('signup-link');
const loginPage = document.getElementById('login-page');
const signupPage = document.getElementById('signup-page');
const loginlink = document.querySelector('#login-link a');

// Add loading animation
const loadingSpinner = document.createElement('div');
loadingSpinner.classList.add('loading-spinner');
loadingSpinner.innerHTML = `
  <div class="spinner-border" role="status">
    <span class="sr-only">Loading...</span>
  </div>
`;
document.body.appendChild(loadingSpinner);

// Function to toggle visibility of login and signup pages
function togglePages() {
  loginPage.classList.toggle('hidden');
  signupPage.classList.toggle('hidden');
}

// Add event listeners
loginBtn.addEventListener('click', () => {
  loginPage.style.display = 'block';
  signupPage.style.display = 'none';
});

signupLink.addEventListener('click', (e) => {
  e.preventDefault();
  signupPage.style.display = 'block';
  loginPage.style.display = 'none';
});

if (loginlink) {
  loginlink.addEventListener('click', (e) => {
    e.preventDefault();
    loginPage.style.display = 'block';
    signupPage.style.display = 'none';
  });
}

// Hide signup page initially
window.onload = function() {
  signupPage.style.display = 'none';
}

// Add validation to login and signup forms
const loginForm = document.querySelector('#login-page form');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('username2').value;
  const password = document.getElementById('password2').value;
  if (!validateEmail(email) || !validatePassword(password)) {
    alert('Invalid email or password');
    return false;
  }
  // Show loading animation
  loadingSpinner.classList.remove('hidden');
  // Simulate authentication process
  setTimeout(() => {
    // Hide loading animation
    loadingSpinner.classList.add('hidden');
    // Display success message
    alert('Login successful!');
  }, 2000);
});

const signupForm = document.querySelector('#signup-page form');

signupForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('username1').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  let isValid = true;

  if (!validateName(name) || !validateEmail(email) || !validatePassword(password)) {
    alert('Invalid input');
    isValid = false;
  }

  if (isValid) {
    // Show loading animation
    loadingSpinner.classList.remove('hidden');
    // Simulate authentication process
    setTimeout(() => {
      // Hide loading animation
      loadingSpinner.classList.add('hidden');
      // Display success message
      alert('Signup successful!');
    }, 200);
  }
  return false;
});

// Validation functions
function validateEmail(email) {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email);
}

function validatePassword(password) {
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
}

function validateName(name) {
  const nameRegex = /^[a-zA-Z ]+$/;
  return nameRegex.test(name);
}

// Add ARIA attributes and semantic HTML elements
Array.prototype.forEach.call(loginForm.elements, (element) => {
  if (element.type === 'email' || element.type === 'password') {
    element.setAttribute('aria-label', element.placeholder);
  }
});

Array.prototype.forEach.call(signupForm.elements, (element) => {
  if (element.type === 'text' || element.type === 'email' || element.type === 'password') {
    element.setAttribute('aria-label', element.placeholder);
  }
});